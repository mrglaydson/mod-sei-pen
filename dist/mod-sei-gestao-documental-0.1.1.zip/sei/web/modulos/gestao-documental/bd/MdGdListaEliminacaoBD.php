<?
require_once dirname(__FILE__) . '/../../../SEI.php';

class MdGdListaEliminacaoBD extends InfraBD
{

    public function __construct(InfraIBanco $objInfraIBanco)
    {
        parent::__construct($objInfraIBanco);
    }
}

?>